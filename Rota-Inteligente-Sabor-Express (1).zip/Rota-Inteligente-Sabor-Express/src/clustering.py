
import csv
import numpy as np
from sklearn.cluster import KMeans

def load_orders(orders_csv):
    rows=[]
    with open(orders_csv, encoding="utf-8") as f:
        for i,row in enumerate(csv.DictReader(f)):
            rows.append({"order_id": int(row["order_id"]), "node_id": int(row["node_id"]), 
                         "x": float(row["x"]), "y": float(row["y"])})
    return rows

def kmeans_partition(orders, k):
    X = np.array([[o["x"], o["y"]] for o in orders])
    km = KMeans(n_clusters=k, n_init=10, random_state=0).fit(X)
    for o,label in zip(orders, km.labels_):
        o["cluster"]=int(label)
    return orders, km.cluster_centers_
