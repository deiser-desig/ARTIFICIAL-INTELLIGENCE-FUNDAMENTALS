
import csv, math
from collections import defaultdict, deque

class Graph:
    def __init__(self):
        self.pos = {}          # node_id -> (x,y)
        self.name = {}         # node_id -> name
        self.adj = defaultdict(list)  # node_id -> list[(v, weight)]

    @staticmethod
    def _euclid(a, b):
        (x1,y1),(x2,y2)=a,b
        return math.hypot(x2-x1, y2-y1)

    def load(self, nodes_csv, edges_csv):
        with open(nodes_csv, encoding="utf-8") as f:
            r=csv.DictReader(f)
            for row in r:
                i=int(row["node_id"]); self.name[i]=row["name"]
                self.pos[i]=(float(row["x"]), float(row["y"]))
        with open(edges_csv, encoding="utf-8") as f:
            r=csv.DictReader(f)
            for row in r:
                u=int(row["src"]); v=int(row["dst"]); w=float(row["weight"]); one=int(row["is_one_way"])
                self.adj[u].append((v,w))
                if not one:
                    self.adj[v].append((u,w))
        return self

    # ---------- BFS (unweighted shortest hops) ----------
    def bfs(self, s, t):
        q=deque([s]); parent={s:None}
        while q:
            u=q.popleft()
            if u==t: break
            for v,_ in self.adj[u]:
                if v not in parent:
                    parent[v]=u; q.append(v)
        if t not in parent: return None, math.inf, 0
        # reconstruct; cost = sum of weights along edges on this path
        path=[]; u=t; expanded=len(parent)
        while u is not None: path.append(u); u=parent[u]
        path=path[::-1]
        cost=0.0
        for i in range(len(path)-1):
            u,v=path[i],path[i+1]
            for x,w in self.adj[u]:
                if x==v: cost+=w; break
        return path, cost, expanded

    # ---------- Dijkstra ----------
    def dijkstra(self, s, t):
        import heapq
        dist=defaultdict(lambda: math.inf); parent={}
        dist[s]=0.0; parent[s]=None
        pq=[(0.0,s)]; expanded=0
        while pq:
            d,u=heapq.heappop(pq)
            if d!=dist[u]: continue
            expanded+=1
            if u==t: break
            for v,w in self.adj[u]:
                nd=d+w
                if nd<dist[v]:
                    dist[v]=nd; parent[v]=u; heapq.heappush(pq,(nd,v))
        if t not in parent: return None, math.inf, expanded
        # reconstruct
        path=[]; u=t
        while u is not None: path.append(u); u=parent[u]
        return path[::-1], dist[t], expanded

    # ---------- A* ----------
    def a_star(self, s, t):
        import heapq
        def h(n):
            return self._euclid(self.pos[n], self.pos[t]) * 1.2  # scale -> time-ish
        g=defaultdict(lambda: math.inf); f=defaultdict(lambda: math.inf); parent={}
        g[s]=0.0; f[s]=h(s); parent[s]=None
        pq=[(f[s], s)]; expanded=0
        in_open=set([s])
        while pq:
            _,u=heapq.heappop(pq)
            expanded+=1
            if u==t: break
            for v,w in self.adj[u]:
                tentative=g[u]+w
                if tentative<g[v]:
                    g[v]=tentative; f[v]=tentative+h(v); parent[v]=u
                    heapq.heappush(pq,(f[v],v)); in_open.add(v)
        if t not in parent: return None, math.inf, expanded
        path=[]; u=t
        while u is not None: path.append(u); u=parent[u]
        return path[::-1], g[t], expanded
