
import argparse, csv, os
from pathlib import Path
from .graph import Graph
from .routing import nearest_neighbor_route, two_opt, route_cost
from .clustering import load_orders, kmeans_partition
from .viz import plot_graph

def load_edges_for_plot(G):
    edges=[]
    for u, lst in G.adj.items():
        for v,w in lst:
            if u < v:  # avoid duplicates for undirected
                edges.append((u,v,w))
    return edges

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--nodes", required=True)
    p.add_argument("--edges", required=True)
    p.add_argument("--orders", required=True)
    p.add_argument("--method", default="a_star", choices=["a_star","dijkstra","bfs"])
    p.add_argument("--cluster", default="none", choices=["none","kmeans"])
    p.add_argument("--k", type=int, default=2)
    p.add_argument("--origin", default="Centro")
    p.add_argument("--save-fig", default="docs/rota_resultado.png")
    args = p.parse_args()

    # Load graph
    G=Graph().load(args.nodes, args.edges)

    # map origin name to id
    name2id = {name: nid for nid, name in G.name.items()}
    if args.origin.isdigit():
        origin = int(args.origin)
    else:
        origin = name2id.get(args.origin, None)
        if origin is None:
            raise SystemExit(f"Origem '{args.origin}' não encontrada. Disponíveis: {sorted(G.name.values())}")

    orders = load_orders(args.orders)
    stops = [o["node_id"] for o in orders]

    routes = []
    stats = []

    if args.cluster == "kmeans":
        orders, _ = kmeans_partition(orders, args.k)
        # group stops by cluster
        byc = {}
        for o in orders:
            byc.setdefault(o["cluster"], []).append(o["node_id"])
        for cid, nodes_in_cluster in sorted(byc.items()):
            r, total, expanded = nearest_neighbor_route(G, origin, nodes_in_cluster[:], method=args.method)
            # optional 2-opt
            rcost = route_cost(G, args.method)
            r2 = two_opt(r, rcost)
            routes.append(r2)
            stats.append({"cluster": cid, "paradas": len(nodes_in_cluster), "custo_min": round(total,2), "nos_expandidos": expanded})
    else:
        r, total, expanded = nearest_neighbor_route(G, origin, stops[:], method=args.method)
        rcost = route_cost(G, args.method)
        r2 = two_opt(r, rcost)
        routes.append(r2)
        stats.append({"cluster": 0, "paradas": len(stops), "custo_min": round(total,2), "nos_expandidos": expanded})

    # Save outputs
    Path("outputs").mkdir(exist_ok=True, parents=True)
    with open("outputs/rotas.csv","w",newline="",encoding="utf-8") as f:
        w=csv.writer(f); w.writerow(["cluster","seq_nos"])
        for s,r in zip(stats, routes):
            w.writerow([s["cluster"], "->".join(map(str,r))])

    # Plot
    Path("docs").mkdir(exist_ok=True, parents=True)
    edges_plot = load_edges_for_plot(G)
    plot_graph(G.pos, edges_plot, title="Rotas sugeridas — Sabor Express", routes=routes, save_fig=args.save_fig)

    # Print summary
    print("Resumo:")
    for s in stats:
        print(s)

if __name__ == "__main__":
    main()
