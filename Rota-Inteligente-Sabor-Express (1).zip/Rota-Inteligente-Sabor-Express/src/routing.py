
import math, csv
from .graph import Graph

def nearest_neighbor_route(G: Graph, origin, stops, method="a_star"):
    # Compute pairwise path cost via chosen method
    algo = {"a_star": G.a_star, "dijkstra": G.dijkstra, "bfs": G.bfs}.get(method, G.a_star)
    remaining = stops[:]
    route=[origin]; total=0.0; expanded=0
    curr=origin
    while remaining:
        best=None; best_cost=math.inf; best_path=None; best_exp=0
        for s in remaining:
            path,cost,exp = algo(curr, s)
            if cost<best_cost:
                best_cost=cost; best=s; best_path=path; best_exp=exp
        # append without repeating curr
        if best_path and len(best_path)>1:
            route += best_path[1:]
        curr=best; total+=best_cost; expanded+=best_exp
        remaining.remove(best)
    return route, total, expanded

def two_opt(route, cost_fn):
    improved=True
    best=route[:]
    while improved:
        improved=False
        for i in range(1, len(best)-2):
            for j in range(i+1, len(best)-1):
                a,b = best[i-1], best[i]
                c,d = best[j], best[j+1]
                old = cost_fn(a,b) + cost_fn(c,d)
                new = cost_fn(a,c) + cost_fn(b,d)
                if new + 1e-9 < old:
                    best[i:j+1]=reversed(best[i:j+1])
                    improved=True
    return best

def route_cost(G: Graph, method):
    algo = {"a_star": G.a_star, "dijkstra": G.dijkstra, "bfs": G.bfs}.get(method, G.a_star)
    def cost(a,b):
        _,c,_ = algo(a,b)
        return c
    return cost
