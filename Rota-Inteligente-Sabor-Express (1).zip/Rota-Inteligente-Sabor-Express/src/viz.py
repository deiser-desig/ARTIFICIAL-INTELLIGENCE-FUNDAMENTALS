
import matplotlib.pyplot as plt

def plot_graph(pos, edges, title=None, routes=None, save_fig=None):
    fig, ax = plt.subplots(figsize=(8,6))
    # draw edges
    for (u,v,w) in edges:
        x1,y1 = pos[u]
        x2,y2 = pos[v]
        ax.plot([x1,x2],[y1,y2], linewidth=1)
        mx,my=(x1+x2)/2,(y1+y2)/2
        ax.text(mx,my,f"{w:.1f}", fontsize=7, ha="center")
    # draw nodes
    for nid,(x,y) in pos.items():
        ax.scatter([x],[y], s=80)
        ax.text(x, y+0.12, f"{nid}", fontsize=8, ha="center")
    # draw routes
    if routes:
        for r in routes:
            xs=[pos[n][0] for n in r]
            ys=[pos[n][1] for n in r]
            ax.plot(xs, ys, linewidth=2)
    ax.set_title(title or "Grafo — Sabor Express (pesos = tempo)")
    ax.set_axis_off()
    plt.tight_layout()
    if save_fig:
        plt.savefig(save_fig, dpi=200, bbox_inches="tight")
    return fig, ax
